# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 21:21:59 2019

@author: Hassan Shakeel
"""

in_ = input("Enter file name: ")
 
fname = 'C:\\Users\\Hassan Shakeel\\Desktop\\'+in_

num_words = 0
no_lines = 0
non_space_char = 0
text = ''
no_tabs = 0

with open(fname, 'r') as f:
    for line in f:
        no_lines += 1
        words = line.split()
        num_words += len(words)
        non_space_char += (len(line)-num_words-1)
        text += line 
        no_tabs += (len(line.split('\t'))-1)
        
print("Number of words: " + str(num_words))
print("Number of non space characters: " + str(non_space_char))
print("Number of spaces: " + str(len(text.split())-1))
print("Number of lines: " + str(no_lines))


