# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 21:49:21 2019

@author: Hassan Shakeel
"""

def tag_identifier(line,tags):
    tags.append('')
    flag = False
    for i in range(len(line)):
        if line[i] == '<':
            if not(flag):
                flag = True
            else:
               flag = False
               tags[len(tags)-1] = ''
               
        elif line[i].isalpha() and flag:
            tags[len(tags)-1] += str(line[i])
        elif line[i] == '>' and flag:
            tags.append('')
            flag = False
        else:
            flag = False
            tags[len(tags)-1] = ''
            
    return tags

fname = 'D:\\Courses\\Harvard- Web Programming\\src0\\border.html'

num_words = 0
tags = []

with open(fname, 'r') as f:
    for line in f:
        tag_identifier(line,tags)
        
result= []
for i in tags:
    if i != '':
        result.append(i)
print(result)
print('tags: '+str(len(result)))